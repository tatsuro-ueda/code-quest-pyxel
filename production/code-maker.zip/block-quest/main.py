# Auto-generated Code Maker classroom bundle.
import hashlib
import pyxel

CORE_BLOCK = '"""Block Quest runtime shim (P1.5-E で <50 行に圧縮)。\n\n真の entry point は `src/runtime/app.py::run`。tests / Code Maker bundler /\n旧 `import src.runtime.main_runtime as M` の互換のため、module-level 名前を\nここで再エクスポートする。\n"""\nfrom __future__ import annotations\nimport pyxel  # tests が M.pyxel 経由で参照する\nfrom src.shared.services.input_bindings import *\nfrom src.shared.services.landmark_events import *\nfrom src.shared.services.player_state import *\nfrom src.shared.services.save_store import *\nfrom src.shared.services.browser_resource_override import *\nfrom src.shared.services.audio_system import *\nfrom src.shared.services.dialog_runner import *\nfrom src.game_data import *\nfrom src.shared.assets.jp_font_data import *\nfrom src.shared.constants.tile_data import *\nfrom src.shared.constants.tile_data import _PATH_VARIANTS, _SHORE_VARIANTS, _ZONE_DECORATIONS\nfrom src.shared.constants.sprite_data import *\nfrom src.shared.constants.game_config import *\nfrom src.shared.services.world_generation import *\nfrom src.shared.services.text_format import NAME_EN_MAP, name_en, TextFormat\nfrom src.shared.services.message_display import MessageDisplay\nfrom src.shared.services.image_banks import ImageBanks\nfrom src.shared.services.vfx import VfxSystem\nfrom src.shared.services.item_use import use_item as _item_use_fn\nfrom src.shared.ui.status_bar import StatusBar\nfrom src.shared.services.audio_system import sync_audio as _sync_audio_fn\nfrom src.scenes.splash.scene import SplashScene\nfrom src.scenes.title.scene import TitleScene\nfrom src.scenes.explore.scene import ExploreScene\nfrom src.scenes.shop.scene import ShopScene\nfrom src.scenes.menu.scene import MenuScene\nfrom src.scenes.ai_help.scene import AiHelpScene\nfrom src.scenes.ending.scene import EndingScene\nfrom src.scenes.settings.scene import SettingsScene\nfrom src.scenes.town.scene import TownScene\nfrom src.scenes.professor.scene import ProfessorScene\nfrom src.scenes.battle.scene import BattleScene\nfrom src.runtime.app import Game, say, say_clear\nfrom src.runtime.app import run as _run\n'
CORE_HASH = "202adaa47e08e7aeaa75ddb3c66bda6ecedc7c85d94b7eb946cbece9a15e127a"

def _sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def _show_core_guard_message():
    pyxel.init(256, 240, title="Block Quest")
    def update():
        pass

    def draw():
        pyxel.cls(0)
        pyxel.text(24, 72, "コアを へんこうしています", 8)
        pyxel.text(24, 92, "STUDENT AREA だけを", 7)
        pyxel.text(24, 108, "へんしゅうしてください", 7)
        pyxel.text(24, 140, "リソースファイルは", 6)
        pyxel.text(24, 156, "リソースエディタで", 6)
        pyxel.text(24, 172, "あつかいます", 6)

    pyxel.run(update, draw)

def verify_core():
    if _sha256_text(CORE_BLOCK) != CORE_HASH:
        _show_core_guard_message()
        raise SystemExit("core block modified")

verify_core()
exec(CORE_BLOCK, globals())

# BEGIN STUDENT AREA
# ここだけ かいてよい
# たとえば:
# say("こんにちは")
# リソースファイルは リソースエディタで へんしゅうします
# END STUDENT AREA

# =====================================================================
# ENTRY POINT
# =====================================================================
def run():
    """Block Quest の entry point。Game を生成して pyxel.run に入る。"""
    return _run()
